@extends('layouts.front')

@section('banner')

@endsection
